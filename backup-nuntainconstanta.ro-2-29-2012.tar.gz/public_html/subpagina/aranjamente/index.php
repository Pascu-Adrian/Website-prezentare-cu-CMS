<?php
header('Location: http://www.nuntainconstanta.ro/pagina.php?categorie=Aranjamente%20florale');
?>