<?php
header('Location: http://www.nuntainconstanta.ro/pagina.php?categorie=Galerie%20foto');
?>