<table width="100%" border="0" cellspacing="0" cellpadding="0" style="position:fixed;bottom:0px;left:0px; width:100%;height:30px;background-color:#5b7bb4;clear:both;text-align:center;">
  <tr>
  
  
    <td>
    <div class="fb-like" data-href="http://www.facebook.com/ArtDecoMariaj" data-send="false" data-layout="button_count" data-width="100" data-show-faces="false" data-font="arial"></div>
    </td>
    
    
    <td >
    <div class="g-plusone" data-width="200" data-href="http://www.nuntainconstanta.ro"></div>
    </td>
    
    
    <td >
    <div class="fb-subscribe" data-href="http://www.facebook.com/ArtDecoMariaj" data-layout="button_count" data-show-faces="false" data-font="arial" data-width="200"></div>
    </td>
  </tr>
</table>

<!--<script>
var options={ "publisher": "ur-1c343533-1b41-ac39-1ed0-2c09fece5728", "position": "right", "ad": { "visible": false, "openDelay": 5, "closeDelay": 0}, "chicklets": { "items": ["facebook", "twitter", "google", "linkedin", "google_bmarks", "yahoo", "blogger", "email", "sharethis"]}};
var st_hover_widget = new sharethis.widgets.hoverbuttons(options);
</script>-->