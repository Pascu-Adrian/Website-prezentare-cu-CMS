<table width="989" border="0" cellspacing="0" cellpadding="0" style="background-image:url(images/footer_background.png);background-repeat:no-repeat;height:31px;margin-left:14px;">
  <tr>
    <td width="25%"></td>
    <td width="75%" align="center">&copy;ArtDecoMariaj Constanta 2011-<?php echo date("Y"); ?>  . toate drepturile rezervate</td>
  </tr>
</table>