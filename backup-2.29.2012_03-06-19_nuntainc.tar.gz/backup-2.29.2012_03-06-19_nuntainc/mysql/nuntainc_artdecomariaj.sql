-- MySQL dump 10.13  Distrib 5.1.56, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: nuntainc_artdecomariaj
-- ------------------------------------------------------
-- Server version	5.1.56-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `datepagini`
--

DROP TABLE IF EXISTS `datepagini`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datepagini` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(500) NOT NULL,
  `descriere` varchar(500) NOT NULL,
  `cuvintecheie` varchar(500) NOT NULL,
  `tip` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datepagini`
--

LOCK TABLES `datepagini` WRITE;
/*!40000 ALTER TABLE `datepagini` DISABLE KEYS */;
INSERT INTO `datepagini` (`id`, `nume`, `descriere`, `cuvintecheie`, `tip`) VALUES (3,'Aranjamente florale','aranjamente florale','aranjamente florale','galerie'),(4,'Galerie foto','Galerie foto','Galerie foto','galerie'),(5,'pachete speciale','pachete speciale','pachete speciale','listaobiecte'),(7,'acasa','acasa','acasa','lista'),(8,'servicii','servicii','servicii','lista'),(9,'contact','contact','contact','listaobiecte');
/*!40000 ALTER TABLE `datepagini` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `img-Aranjamente florale`
--

DROP TABLE IF EXISTS `img-Aranjamente florale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `img-Aranjamente florale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` int(11) NOT NULL,
  `idcategorie` int(11) NOT NULL,
  `imagine` varchar(250) NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idcategorie` (`idcategorie`),
  CONSTRAINT `img@002dAranjamente@0020florale_ibfk_1` FOREIGN KEY (`idcategorie`) REFERENCES `pag-Aranjamente florale` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `img-Aranjamente florale`
--

LOCK TABLES `img-Aranjamente florale` WRITE;
/*!40000 ALTER TABLE `img-Aranjamente florale` DISABLE KEYS */;
INSERT INTO `img-Aranjamente florale` (`id`, `nume`, `idcategorie`, `imagine`, `pozitie`, `activ`) VALUES (1,0,1,'DSC_4319.png',0,1),(2,0,1,'IMAGE_309.jpg',0,1),(3,0,1,'IMAGE_291.jpg',0,1),(4,0,1,'DSC_4253.png',0,1),(5,0,1,'DSC_4037.png',0,1),(6,0,1,'DSC_4314.png',0,1),(7,0,1,'nou1.jpg',0,1),(8,0,2,'flori 047.jpg',0,1),(9,19,2,'19-07-08_0800.jpg',0,1),(10,0,2,'buchetul-miresei-102.jpg',0,1),(11,0,2,'flori 021.jpg',0,1),(12,0,2,'buchetul-miresei-095.jpg',0,1),(13,2147483647,2,'102309200404.jpg',0,1),(14,2147483647,2,'040510100158.jpg',0,1),(15,0,2,'bm012.jpg',0,1),(16,0,2,'IMAGE_006.jpg',0,1),(17,0,2,'bouquet2.jpg',0,1),(18,0,2,'bm005.jpg',0,1),(19,2147483647,2,'112809114613.jpg',0,1),(20,58298823,2,'58298823.tulipbouqet3.jpg',0,1);
/*!40000 ALTER TABLE `img-Aranjamente florale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `img-Galerie foto`
--

DROP TABLE IF EXISTS `img-Galerie foto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `img-Galerie foto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` int(11) NOT NULL,
  `idcategorie` int(11) NOT NULL,
  `imagine` varchar(250) NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idcategorie` (`idcategorie`),
  CONSTRAINT `img@002dGalerie@0020foto_ibfk_1` FOREIGN KEY (`idcategorie`) REFERENCES `pag-Galerie foto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `img-Galerie foto`
--

LOCK TABLES `img-Galerie foto` WRITE;
/*!40000 ALTER TABLE `img-Galerie foto` DISABLE KEYS */;
INSERT INTO `img-Galerie foto` (`id`, `nume`, `idcategorie`, `imagine`, `pozitie`, `activ`) VALUES (1,1,5,'1IMG_5684.jpg',0,1),(2,0,5,'IMG_5685.jpg',0,1),(3,1,5,'1IMG_5632.jpg',0,1),(4,0,5,'Fotografie0140.jpg',0,1),(5,0,5,'IMG_5689.jpg',0,1),(6,0,5,'IMG_5632.jpg',0,1),(7,0,5,'IMG_5659.jpg',0,1),(8,0,5,'IMG_5684.jpg',0,1),(9,0,5,'IMG_5658.jpg',0,1),(10,0,5,'IMG_5655.jpg',0,1),(11,45932,4,'45932_148048748552282_142645702425920_329456_8244850_n.jpg',0,1),(12,45932,4,'45932_148048745218949_142645702425920_329455_5497125_n.jpg',0,1),(13,46076,4,'46076_148170735206750_142645702425920_329924_2687183_n.jpg',0,1),(14,46076,4,'46076_148170731873417_142645702425920_329923_4861358_n.jpg',0,1),(15,40050,4,'40050_148048791885611_142645702425920_329458_2880229_n.jpg',0,1),(16,45932,4,'45932_148048751885615_142645702425920_329457_3956466_n.jpg',0,1),(17,45861,4,'45861_148170705206753_142645702425920_329922_1650869_n.jpg',0,1),(18,0,4,'servicii.png',0,1),(19,0,3,'dsc - 0327.jpg',0,1),(20,0,3,'dsc - 0326.jpg',0,1),(21,0,3,'dsc - 0331.jpg',0,1),(22,0,3,'dsc - 0333.jpg',0,1),(23,0,3,'dsc - 0330.jpg',0,1),(24,0,1,'DSC_4069.png',0,1),(25,0,1,'DSC_4045.png',0,1),(26,0,1,'DSC_4294.png',0,1),(27,0,1,'DSC_4331.png',0,1),(28,0,1,'DSC_4302.png',0,1),(29,0,1,'DSC_4235.png',0,1),(30,0,1,'DSC_4287.png',0,1),(31,0,1,'DSC_4216.png',0,1),(159,1,2,'1dsc - 0337.jpg',0,1),(160,0,2,'pic 181.jpg',0,1),(161,0,2,'dsc - 0340.jpg',0,1),(162,0,2,'dsc - 0341.jpg',0,1),(163,0,2,'pic 256.jpg',0,1),(164,1,2,'1dsc - 0336.jpg',0,1),(165,0,2,'pic 183.jpg',0,1),(166,0,2,'pic 182.jpg',0,1),(167,1,2,'1pic 545.jpg',0,1),(168,0,2,'dsc - 0342.jpg',0,1),(169,0,2,'pic 259.jpg',0,1),(170,0,2,'dsc - 0338.jpg',0,1);
/*!40000 ALTER TABLE `img-Galerie foto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obj-contact`
--

DROP TABLE IF EXISTS `obj-contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obj-contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) NOT NULL,
  `text` text,
  `idcategorie` int(11) NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idcategorie` (`idcategorie`),
  CONSTRAINT `obj@002dcontact_ibfk_1` FOREIGN KEY (`idcategorie`) REFERENCES `pag-contact` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obj-contact`
--

LOCK TABLES `obj-contact` WRITE;
/*!40000 ALTER TABLE `obj-contact` DISABLE KEYS */;
INSERT INTO `obj-contact` (`id`, `nume`, `text`, `idcategorie`, `pozitie`, `activ`) VALUES (1,'LUCIANA:','0762 295 423',1,3,1),(2,'MARCELA:','0766 478 083',1,4,1),(3,'LUCIANA','Luciana@nuntainconstanta.ro',2,1,1),(4,'MARCELA','Marcela@nuntainconstanta.ro',2,2,1);
/*!40000 ALTER TABLE `obj-contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obj-pachete speciale`
--

DROP TABLE IF EXISTS `obj-pachete speciale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obj-pachete speciale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) NOT NULL,
  `text` text,
  `idcategorie` int(11) NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idcategorie` (`idcategorie`),
  CONSTRAINT `obj@002dpachete@0020speciale_ibfk_1` FOREIGN KEY (`idcategorie`) REFERENCES `pag-pachete speciale` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obj-pachete speciale`
--

LOCK TABLES `obj-pachete speciale` WRITE;
/*!40000 ALTER TABLE `obj-pachete speciale` DISABLE KEYS */;
/*!40000 ALTER TABLE `obj-pachete speciale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pag-Aranjamente florale`
--

DROP TABLE IF EXISTS `pag-Aranjamente florale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pag-Aranjamente florale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) NOT NULL,
  `imagine` varchar(250) DEFAULT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pag-Aranjamente florale`
--

LOCK TABLES `pag-Aranjamente florale` WRITE;
/*!40000 ALTER TABLE `pag-Aranjamente florale` DISABLE KEYS */;
INSERT INTO `pag-Aranjamente florale` (`id`, `nume`, `imagine`, `pozitie`, `activ`) VALUES (1,'Aranjamente','nou1.jpg',2,1),(2,'Buchete rotunde','buchetul-miresei-102.jpg',1,1);
/*!40000 ALTER TABLE `pag-Aranjamente florale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pag-Galerie foto`
--

DROP TABLE IF EXISTS `pag-Galerie foto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pag-Galerie foto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) NOT NULL,
  `imagine` varchar(250) DEFAULT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pag-Galerie foto`
--

LOCK TABLES `pag-Galerie foto` WRITE;
/*!40000 ALTER TABLE `pag-Galerie foto` DISABLE KEYS */;
INSERT INTO `pag-Galerie foto` (`id`, `nume`, `imagine`, `pozitie`, `activ`) VALUES (1,'decoratiuni saloane','DSC_4302.png',5,1),(2,'fantana de ciocolata si sculpturi in fructe','pic 259.jpg',4,1),(3,'fantana de sampanie','dsc - 0333.jpg',3,1),(4,'salon pe rosu','46076_148170731873417_142645702425920_329923_4861358_n.jpg',2,1),(5,'tema marina','IMG_5655.jpg',1,1);
/*!40000 ALTER TABLE `pag-Galerie foto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pag-acasa`
--

DROP TABLE IF EXISTS `pag-acasa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pag-acasa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) DEFAULT NULL,
  `text` text,
  `imagine` varchar(250) DEFAULT NULL,
  `pozitieimagine` int(11) NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`),
  KEY `pozitieimagine` (`pozitieimagine`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pag-acasa`
--

LOCK TABLES `pag-acasa` WRITE;
/*!40000 ALTER TABLE `pag-acasa` DISABLE KEYS */;
INSERT INTO `pag-acasa` (`id`, `nume`, `text`, `imagine`, `pozitieimagine`, `pozitie`, `activ`) VALUES (1,'Despre noi','ArtDeco Mariaj este o firma conceputa pentru a va usura organizarea evenimentelor importante din viata dvs. ( nunti, botezuri, petreceri copii, banchete, aniversari, evenimente corporate, lansari produse, petreceri cu tematica Halloween, Craciun, etc). Pentru toate acestea noi va oferim consultanta, idei de amenajari si decoratiuni preluand agitatia, tensiunea si stresul, facandu-va astfel sa va simtit invitati la propriul eveniment! ','artdecomariaj.png',1,1,1),(2,'Decorarea salonului','Ne dorim sa devenim prima optiune in domeniul organizarii de evenimente, prin indeplinirea obiectivelor de performanta: calitate, incredere, promptitudine, flexibilitate, CEL MAI BUN PRET PENTRU CELE MAI BUNE SERVICII.','DSC_4302.png',4,2,1),(3,'Servicii oferite','Pentru a realiza un eveniment, ArtDeco Mariaj va pune la dispozitie o gama larga de produse si servicii, incepand cu decoratiuni salon, aranjamente florale, accesorii, entertainment, fantana de ciocolata, fantana sampanie, sculpturi fructe, servicii foto/video, hostess, si multe altele.','dsc---0341.png',1,3,1);
/*!40000 ALTER TABLE `pag-acasa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pag-banner`
--

DROP TABLE IF EXISTS `pag-banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pag-banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(255) NOT NULL,
  `imagine` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`),
  UNIQUE KEY `pozitie` (`pozitie`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pag-banner`
--

LOCK TABLES `pag-banner` WRITE;
/*!40000 ALTER TABLE `pag-banner` DISABLE KEYS */;
INSERT INTO `pag-banner` (`id`, `nume`, `imagine`, `text`, `pozitie`, `activ`) VALUES (1,'floraria luana','reclama.png','http://www.facebook.com/floraria.luana?sk=photos',1,1),(2,'COMPLEX LAGUNA','reclama2.png','http://www.complexlaguna.ro',2,1);
/*!40000 ALTER TABLE `pag-banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pag-contact`
--

DROP TABLE IF EXISTS `pag-contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pag-contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pag-contact`
--

LOCK TABLES `pag-contact` WRITE;
/*!40000 ALTER TABLE `pag-contact` DISABLE KEYS */;
INSERT INTO `pag-contact` (`id`, `nume`, `pozitie`, `activ`) VALUES (1,'TELEFON',1,1),(2,'Mail',2,1);
/*!40000 ALTER TABLE `pag-contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pag-pachete speciale`
--

DROP TABLE IF EXISTS `pag-pachete speciale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pag-pachete speciale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) NOT NULL,
  `pret` int(11) DEFAULT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pag-pachete speciale`
--

LOCK TABLES `pag-pachete speciale` WRITE;
/*!40000 ALTER TABLE `pag-pachete speciale` DISABLE KEYS */;
/*!40000 ALTER TABLE `pag-pachete speciale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pag-servicii`
--

DROP TABLE IF EXISTS `pag-servicii`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pag-servicii` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(50) DEFAULT NULL,
  `text` text,
  `imagine` varchar(250) DEFAULT NULL,
  `pozitieimagine` int(11) NOT NULL,
  `pozitie` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nume` (`nume`),
  KEY `pozitieimagine` (`pozitieimagine`),
  CONSTRAINT `pag@002dservicii_ibfk_1` FOREIGN KEY (`pozitieimagine`) REFERENCES `pozitieimagine` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pag-servicii`
--

LOCK TABLES `pag-servicii` WRITE;
/*!40000 ALTER TABLE `pag-servicii` DISABLE KEYS */;
INSERT INTO `pag-servicii` (`id`, `nume`, `text`, `imagine`, `pozitieimagine`, `pozitie`, `activ`) VALUES (1,'Servicii oferite','Fiecare client este unic si trebuie sa se simta special. Fie ca alegeti o tema speciala sau doriti doar sa aduceti un plus de eleganta salonului in care se desfasoara evenimentul dvs, event-plannerii ArtDeco Mariaj va stau la dispozitie pentru a va pune in practica dorintele pana la cel mai mic detaliu.\r\n<br/>Si anume: \r\n<br/>~ Invitatii de nunta \r\n<br/>~ Restaurante \r\n<br/>~ Decoratiuni cu baloane\r\n<br/>~ Aranjamente florale \r\n<br/>~ Filmari video \r\n<br/>~ Fotografii \r\n<br/>~ Formatie cu muzica live \r\n<br/>~ Dj \r\n<br/>~ Artificii \r\n<br/>~ Dansatoare, ursitoare ~ Salon de infrumusetare \r\n<br/>~ Fantana de ciocolata\r\n<br/>~ Sculpturi fructe \r\n<br/>~ Fantana de sampanie \r\n<br/>~ Fete de masa pentru mesele invitatilor (din brocard) \r\n<br/>~ Fata de masa pentru masa mirilor (din brocard cu fusta) \r\n<br/>~ Huse pentru scaune\r\n<br/>~ Arcada flori naturale/artificale\r\n<br/>~ Elemente de decor din fier forjat \r\n<br/>~ Elemente de decor din sticla \r\n<br/>~ Stalpi pentru lumanari\r\n<br/>~ Casuta de bani (diferite modele) \r\n<br/>~ Covor rosu cu stalpi decor din fier forjat (aranjamente florale) \r\n<br/>~ Marturii \r\n<br/>~ Buchete, lumanari, cocarde ','oijuok.png',1,1,1);
/*!40000 ALTER TABLE `pag-servicii` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pozitieimagine`
--

DROP TABLE IF EXISTS `pozitieimagine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pozitieimagine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pozitieimagine`
--

LOCK TABLES `pozitieimagine` WRITE;
/*!40000 ALTER TABLE `pozitieimagine` DISABLE KEYS */;
INSERT INTO `pozitieimagine` (`id`, `nume`) VALUES (1,'stanga-sus'),(2,'stanga-mijloc'),(3,'stanga-jos'),(4,'dreapta-sus'),(5,'dreapta-mijloc'),(6,'dreapta-jos');
/*!40000 ALTER TABLE `pozitieimagine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `username`, `password`) VALUES (1,'mindslave','a2bd24aebfdeea74a882ae3f53359342');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'nuntainc_artdecomariaj'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-02-29  3:06:28
