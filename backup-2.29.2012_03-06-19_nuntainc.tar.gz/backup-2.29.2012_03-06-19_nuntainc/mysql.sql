-- cPanel mysql backup
GRANT USAGE ON *.* TO 'nuntainc'@'localhost' IDENTIFIED BY PASSWORD '7c9bdade6271f593';
GRANT ALL PRIVILEGES ON `nuntainc\_artdecomariaj`.* TO 'nuntainc'@'localhost';
GRANT ALL PRIVILEGES ON `nuntainc\_%`.* TO 'nuntainc'@'localhost';
GRANT USAGE ON *.* TO 'nuntainc_root'@'localhost' IDENTIFIED BY PASSWORD '406d41ba34c1b0a5';
GRANT ALL PRIVILEGES ON `nuntainc\_artdecomariaj`.* TO 'nuntainc_root'@'localhost';
